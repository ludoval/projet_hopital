/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;

/**
 *
 * @author ludovic
 */
public class Malade {
    //attributs
    private String numero;
    private String nom;
    private String prenom;
    private String tel;
    private String adresse;
    //getters 
    public String getNumero(){return numero;}
    public String getPrenom(){return  prenom;}
    public String getNom(){return nom;}
    public String getTel(){return tel;}
    public String getAdresse(){return adresse;}
    //setters
    public void setNumero(String num){this.numero=num;}
    public void setPrenom(String a){this.prenom=a;}
    public void setNom(String a){this.nom=a;}
    public void setTel(String a){this.tel=a;}
    public void setAdresse(String a){this.adresse=a;}
    //constructeur
    public Malade(String num,String surname,String lastname,String phone,String ad){
        numero=num;
        prenom=surname;
        nom=lastname;
        tel=phone;
        adresse=ad;
    }
    
}
