/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;

/**
 *
 * @author ludovic
 */
public class Chambre {
    //attributs
    private int no_chambre;
    private int surveillant;
    private int nb_lits;
    //getters 
    public int getNumChambre(){return no_chambre;}
    public int getSurveillant(){return surveillant;}
    public int getNbLits(){return nb_lits;}
}
