/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author ludovic
 */
public class Malade {
    //attributs
    private int numero;
    private String nom;
    private String prenom;
    private String tel;
    private String adresse;
    //getters 
    public int getNumero(){return numero;}
    public String getPrenom(){return  prenom;}
    public String getNom(){return nom;}
    public String getTel(){return tel;}
    public String getAdresse(){return adresse;}
    
}
