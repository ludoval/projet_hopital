/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modele;

/**
 *
 * @author ludovic
 */
public abstract class Employe{
    //attribut
    protected String numero;
    protected String nom;
    protected String prenom;
    protected String tel;
    protected String adresse;
    protected double salaire;
    protected String rotation;
    //getters 
    /*public String getNumero(){return numero;}
    public String getNom(){return nom;}
    public String getPrenom(){return prenom;}
    public String getTel(){return tel;}
    public String getAdresse(){return adresse;}
    public double getSalaire(){return salaire;}
    public String getRotation(){return rotation;}*/
}
