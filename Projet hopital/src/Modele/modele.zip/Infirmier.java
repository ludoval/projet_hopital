/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modele;

/**
 *
 * @author ludovic
 */
public class Infirmier extends Employe{
    private double salaire;
    private String rotation;
    private String nom_serv;
    public Infirmier(String numero, String nom, String prenom, String tel, String adresse,double salaire,String rotation,String nse) {
        super(numero, nom, prenom, tel, adresse);
        this.salaire=salaire;
        this.rotation=rotation;
        this.nom_serv=nse;
    }

    public double getSalaire(){
        return salaire;
        }
    public String getRotation(){
        return rotation;
        }
    public String getNomService(){return nom_serv;}
}